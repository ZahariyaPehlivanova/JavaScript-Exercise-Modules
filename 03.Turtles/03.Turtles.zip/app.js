result.Turtle = require('./Turtle');
result.EvkodianTurtle = require('./EvkodianTurtle');
result.GalapagosTurtle = require('./GalapagosTurtle');
result.NinjaTurtle = require('./NinjaTurtle');
result.WaterTurtle = require('./WaterTurtle');