let Employee = require('./Employee');

class Branch {
    constructor(id, branchName, companyName) {
        this.id = id;
        this.branchName = branchName;
        this.companyName = companyName;

        let _employees = [];
    }

    get employees() {
        return _employees;
    }

    hire(employee) {
        _employees.push(employee);
    }

    toString() {
        let output = `@ ${this.companyName}, ${this.branchName}, ${this.id}\n`;
        output += 'Employed:\n';
        if (_employees.length == 0) {
            output += 'None…';
        } else {
            for (let employee of this.employees) {
                output += `** ${employee}\n`;
            }
        }
        return output.trim();
    }
}
module.exports = Branch;